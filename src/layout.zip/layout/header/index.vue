<template>
  <div class="header">
    <div class="header-top">
      <div class="header-top-left">
        <div class="fold" @click="store.isFold = !store.isFold">
          <i :class="[store.isFold ? 'r4 r4-expand' : 'r4 r4-fold']"></i>
        </div>
      </div>
      <div class="header-top-right">
        <div class="langSelect">
          <LangSelect />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import LangSelect from '@/components/LangSelect/index.vue';
import { useAppStore } from '@/store/app'

const store = useAppStore()
</script>

<style scoped lang="scss">
.header {
  height: 50px;
  border-bottom: 1px solid #ccc;

  &-top {
    height: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    &-left {
      .fold {
        height: 50px;
        width: 35px;
        text-align: center;
        cursor: pointer;

        &:hover {
          background-color: #e5e7eb;
        }

        i {
          position: relative;
          top: 30%;
        }
      }
    }

    &-right {
      .langSelect {
        margin-right: 20px;
      }
    }
  }
}
</style>